/**
 *Dbconnection.java
 */


package org.example.DBconnection;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Vector;



public class DBConnectionMgr {

	private Vector<ConnectionObject> connections;
	private String _driver;
	private String _url;
	private String _user;
	private String _password;
	private boolean _tranceOn;
	private boolean Initiallzed;
	private int _openConnections; 
	private static DBConnectionMgr Instance;



	public DBConnectionMgr(){

		this.connections  = new Vector<ConnectionObject>(); 
		this._driver = "com.mysql.cj.jdbc.Driver";
		this._url = "jdbc:mysql://127.0.0.1:3307/hospital";
		this._user = "webproject";
		this._password = "8615";
		this._tranceOn = false;
		this.Initiallzed = false;
		this._openConnections = 100;
		Instance = null;

	}

	//get handle
	public static DBConnectionMgr getInstance(){
		if(Instance == null){
			synchronized (DBConnectionMgr.class) {
				if(Instance == null){
					Instance = new DBConnectionMgr();
				}

			}
		}
		return Instance;
	}

	public void setOpenConnetionCount(int count){
		this._openConnections = count;
	}


	public boolean Get_tranceOn_cheak() {
		return _tranceOn;
	}

	public void set_trance_Eable(boolean enable) {
		this._tranceOn = enable;
	}

	public Vector<ConnectionObject> getConnectionList(){
		return connections;
	}

	public synchronized void setInitOpenConnetions(int count) throws SQLException{

		Connection c = null;
		ConnectionObject co =null;
		for(int i =0; i < count; i++){
			c = createConntion();
			co = new ConnectionObject(c, false);
			this.connections.add(co);
			trace("ConnectionPoolManger: Adding new DB connection to pool("+connections.size()+")"  );


		}
	}

	public int getConnectionCount(){
		return connections.size();
	}

	public synchronized Connection getConnection() throws Exception {

		if(!Initiallzed){ 

			Class<?> c = Class.forName(this._driver);
			DriverManager.registerDriver((Driver)c.newInstance());
			Initiallzed = true;

		}

		Connection c = null;
		ConnectionObject co =null;
		boolean badConnection = false;

		for(int i =0; i < connections.size();i++){

			co = (ConnectionObject)connections.elementAt(i);

			if(co.InUse){

				try{
					badConnection = co.connection.isClosed();
					if(badConnection){
						badConnection = (co.connection.getWarnings() != null);
					}
				}catch (Exception e) {
					// TODO: handle exception
					badConnection = true;
					e.printStackTrace();
				}


				if(badConnection){
					connections.removeElementAt(i);
					//trace
					continue;
				}
				c = co.connection;
				co.InUse = true;
				//trace

				break;
			}
		}
		if(c == null){
			c = createConntion();
			co = new ConnectionObject(c, true);
			connections.add(co);

		}
		return c;
	}



	public synchronized void freeConnection(Connection c){

		if(c == null){
			return;
		}
		ConnectionObject co = null;
		for(int i =0; i < connections.size(); i++){
			co =  (ConnectionObject)connections.elementAt(i);

			if( c == co.connection){
				co.InUse = false;
				break;
			}
		}

		for(int i =0; i < connections.size(); i++){
			co =  (ConnectionObject)connections.elementAt(i);

			if( (i + 1) > _openConnections && co.InUse){
				reMoveConnection(co.connection);
			}
		}
	}


	public void freeConnection(Connection c,PreparedStatement p,ResultSet r){

		try{
			if( r != null) r.close();
			if( p != null) p.close();
			freeConnection(c);
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void freeConnection(Connection c,Statement s,ResultSet r){
		try{
			if( r != null) r.close();
			if( s != null) s.close();
			freeConnection(c);
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void freeConnection(Connection c,PreparedStatement p){
		try{
			if( p != null) p.close();
			freeConnection(c);
		}catch (SQLException e) {
			// TODO: handle exception
		}
	}

	public void freeConnection(Connection c,Statement s ){
		try{
			if( s != null) s.close();
			freeConnection(c);
		}catch (SQLException e) {
			// TODO: handle exception
		}
	}



	@SuppressWarnings("unused")
	public synchronized void reMoveConnection(Connection c){
		if(c == null)
			return;
		ConnectionObject co = null;
		for(int i = 0; i < connections.size(); i++){
			co =  (ConnectionObject)connections.elementAt(i);
			if(c == co.connection ){
				try{
					c.close();
					connections.removeElementAt(i);


				}catch (Exception e) {
					// TODO: handle exception
				}
			}
			break;
		}

	}






	public void releaseFreeConnections(){
		trace("ConnectionPoolManager.releasaFreeConection()");

		//Connection c = null;
		ConnectionObject co = null;
		for(int i = 0; i < connections.size(); i++){
			co = (ConnectionObject)connections.elementAt(i);
			if(!co.InUse)
				reMoveConnection(co.connection);
		}

	}


	public void finallze(){
		trace("ConnectionPoolManager.finallze()");
		//Connection c = null;
		ConnectionObject co = null;
		for(int i = 0; i < connections.size(); i++){
			co =  (ConnectionObject)connections.elementAt(i);

			try{
				co.connection.close();
				connections.removeElementAt(i);


			}catch (Exception e) {
				// TODO: handle exception
			}
			co = null;
		}
		connections.removeAllElements();

	}


	private Connection createConntion() throws SQLException{

		Connection con = null;
		try{

			if(_user == null){
				_user = "";
			}
			if(_password == null){
				_password = "";
			}

			Properties props = new Properties();
			props.put("user",_user);
			props.put("password",_password);
			con = DriverManager.getConnection(_url,props);


		}catch (Throwable e) {
			// TODO: handle exception
			throw new SQLException(e.getMessage());
		}

		return con;
	}

	private void trace(String s){
		if(_tranceOn){
			System.err.println(s);
		}
	}

}
class ConnectionObject{
	
	public Connection connection = null;
	public boolean InUse = false;

	public ConnectionObject(Connection c,boolean flag){
		this.connection = c;
		this.InUse = flag;
	}
}
