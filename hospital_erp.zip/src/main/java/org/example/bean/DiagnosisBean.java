package org.example.bean;

public class DiagnosisBean {

    /**
     * customer info
     *
     */

    private String mem_id;
    private String mem_pwd;
    private String mem_age;
    private String mem_name;


    private String mem_sex;
    private String mem_birthday;
    private String mem_addr;
    private String mem_tel;
    private String mem_phon;
    private String mem_job;

    /**
     * {@value}hopital info
     */

    private String dign_cd;
    private String dign_dise;
    private String dign_insertDay;
    private String dign_year;
    private String dign_age;
    private String dign_sex;
    private String dign_month;
    private String dign_day;
    private String dign_med;
    private String dign_mem_id;

    public DiagnosisBean(){
        mem_id = null;
        mem_pwd= null;
        mem_age= null;
        mem_sex= null;
        mem_birthday= null;
        mem_addr= null;
        mem_tel= null;
        mem_phon= null;
        mem_job= null;


        dign_cd= null;
        dign_dise= null;
        dign_insertDay= null;
        dign_year= null;
        dign_age= null;
        dign_sex= null;
        dign_month= null;
        dign_day= null;
        dign_med= null;
        dign_mem_id= null;

    }

    public String getMem_id() {
        return mem_id;
    }

    public void setMem_id(String mem_id) {
        this.mem_id = mem_id;
    }


    public String getMem_name() {
        return mem_name;
    }

    public void setMem_name(String mem_name) {
        this.mem_name = mem_name;
    }


    public String getMem_pwd() {
        return mem_pwd;
    }

    public void setMem_pwd(String mem_pwd) {
        this.mem_pwd = mem_pwd;
    }

    public String getMem_age() {
        return mem_age;
    }

    public void setMem_age(String mem_age) {
        this.mem_age = mem_age;
    }

    public String getMem_sex() {
        return mem_sex;
    }

    public void setMem_sex(String mem_sex) {
        this.mem_sex = mem_sex;
    }

    public String getMem_birthday() {
        return mem_birthday;
    }

    public void setMem_birthday(String mem_birthday) {
        this.mem_birthday = mem_birthday;
    }

    public String getMem_addr() {
        return mem_addr;
    }

    public void setMem_addr(String mem_addr) {
        this.mem_addr = mem_addr;
    }

    public String getMem_tel() {
        return mem_tel;
    }

    public void setMem_tel(String mem_tel) {
        this.mem_tel = mem_tel;
    }

    public String getMem_phon() {
        return mem_phon;
    }

    public void setMem_phon(String mem_phon) {
        this.mem_phon = mem_phon;
    }

    public String getMem_job() {
        return mem_job;
    }

    public void setMem_job(String mem_job) {
        this.mem_job = mem_job;
    }

    public String getDign_cd() {
        return dign_cd;
    }

    public void setDign_cd(String dign_cd) {
        this.dign_cd = dign_cd;
    }

    public String getDign_dise() {
        return dign_dise;
    }

    public void setDign_dise(String dign_dise) {
        this.dign_dise = dign_dise;
    }

    public String getDign_insertDay() {
        return dign_insertDay;
    }

    public void setDign_insertDay(String dign_insertDay) {
        this.dign_insertDay = dign_insertDay;
    }

    public String getDign_year() {
        return dign_year;
    }

    public void setDign_year(String dign_year) {
        this.dign_year = dign_year;
    }

    public String getDign_age() {
        return dign_age;
    }

    public void setDign_age(String dign_age) {
        this.dign_age = dign_age;
    }

    public String getDign_sex() {
        return dign_sex;
    }

    public void setDign_sex(String dign_sex) {
        this.dign_sex = dign_sex;
    }

    public String getDign_month() {
        return dign_month;
    }

    public void setDign_month(String dign_month) {
        this.dign_month = dign_month;
    }

    public String getDign_day() {
        return dign_day;
    }

    public void setDign_day(String dign_day) {
        this.dign_day = dign_day;
    }

    public String getDign_med() {
        return dign_med;
    }

    public void setDign_med(String dign_med) {
        this.dign_med = dign_med;
    }

    public String getDign_mem_id() {
        return dign_mem_id;
    }

    public void setDign_mem_id(String dign_mem_id) {
        this.dign_mem_id = dign_mem_id;
    }


}

