package org.example.bean;




/**
 *DoctorBean.java
 */




public class DoctorBean {

    private String dcr_id;
    private String dcr_pwd;
    private String dcr_name;
    private String dcr_age;
    private String dcr_sex;
    private String dcr_birthday;
    private String dcr_addr;
    private String dcr_tel;
    private String dcr_phon;


    public String getDcr_id() {
        return dcr_id;
    }
    public void setDcr_id(String dcr_id) {
        this.dcr_id = dcr_id;
    }
    public String getDcr_pwd() {
        return dcr_pwd;
    }
    public void setDcr_pwd(String dcr_pwd) {
        this.dcr_pwd = dcr_pwd;
    }
    public String getDcr_name() {
        return dcr_name;
    }
    public void setDcr_name(String dcr_name) {
        this.dcr_name = dcr_name;
    }
    public String getDcr_age() {
        return dcr_age;
    }
    public void setDcr_age(String dcr_age) {
        this.dcr_age = dcr_age;
    }
    public String getDcr_sex() {
        return dcr_sex;
    }
    public void setDcr_sex(String dcr_sex) {
        this.dcr_sex = dcr_sex;
    }
    public String getDcr_birthday() {
        return dcr_birthday;
    }
    public void setDcr_birthday(String dcr_birthday) {
        this.dcr_birthday = dcr_birthday;
    }
    public String getDcr_addr() {
        return dcr_addr;
    }
    public void setDcr_addr(String dcr_addr) {
        this.dcr_addr = dcr_addr;
    }
    public String getDcr_tel() {
        return dcr_tel;
    }
    public void setDcr_tel(String dcr_tel) {
        this.dcr_tel = dcr_tel;
    }
    public String getDcr_phon() {
        return dcr_phon;
    }
    public void setDcr_phon(String dcr_phon) {
        this.dcr_phon = dcr_phon;
    }



}
