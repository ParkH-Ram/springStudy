package org.example.bean;

public class HospitalBean {

    private String hosp_cd;
    private String hosp_id;
    private String hosp_name;
    private String hosp_tel;
    private String hosp_addr;
    private String hosp_homepage;
    private String hosp_fax;
    private String hosp_img;


    public String getHosp_cd() {
        return hosp_cd;
    }

    public void setHosp_cd(String hosp_cd) {
        this.hosp_cd = hosp_cd;
    }

    public HospitalBean(){

        hosp_id = null;
        hosp_name = null;
        hosp_tel = null;
        hosp_addr = null;
        hosp_homepage = null;
        hosp_fax = null;
        hosp_img = null;

    }

    public String getHosp_id() {
        return hosp_id;
    }

    public void setHosp_id(String hosp_id) {
        this.hosp_id = hosp_id;
    }

    public String getHosp_name() {
        return hosp_name;
    }

    public void setHosp_name(String hosp_name) {
        this.hosp_name = hosp_name;
    }

    public String getHosp_tel() {
        return hosp_tel;
    }

    public void setHosp_tel(String hosp_tel) {
        this.hosp_tel = hosp_tel;
    }

    public String getHosp_addr() {
        return hosp_addr;
    }

    public void setHosp_addr(String hosp_addr) {
        this.hosp_addr = hosp_addr;
    }

    public String getHosp_homepage() {
        return hosp_homepage;
    }

    public void setHosp_homepage(String hosp_homepage) {
        this.hosp_homepage = hosp_homepage;
    }

    public String getHosp_fax() {
        return hosp_fax;
    }

    public void setHosp_fax(String hosp_fax) {
        this.hosp_fax = hosp_fax;
    }

    public String getHosp_img() {
        return hosp_img;
    }

    public void setHosp_img(String hosp_img) {
        this.hosp_img = hosp_img;
    }


}
