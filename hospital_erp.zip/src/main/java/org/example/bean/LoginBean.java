/**
*LoginBean.java
*/


package org.example.bean;

public class LoginBean {
	
	private String mem_id;
	private String mem_pwd;
	
	public LoginBean(){
		mem_id = null;
		mem_pwd = null;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getMem_pwd() {
		return mem_pwd;
	}

	public void setMem_pwd(String mem_pwd) {
		this.mem_pwd = mem_pwd;
	}
	

}
