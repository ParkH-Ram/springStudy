/**
*MedBean.java
*/


package org.example.bean;

public class MedBean {

	private String med_cd;
	private String med_name;
	private String med_ucost;
	private String med_eff;
	
	
	public String getMed_cd() {
		return med_cd;
	}
	public void setMed_cd(String med_cd) {
		this.med_cd = med_cd;
	}
	public String getMed_name() {
		return med_name;
	}
	public void setMed_name(String med_name) {
		this.med_name = med_name;
	}
	public String getMed_ucost() {
		return med_ucost;
	}
	public void setMed_ucost(String med_ucost) {
		this.med_ucost = med_ucost;
	}
	public String getMed_eff() {
		return med_eff;
	}
	public void setMed_eff(String med_eff) {
		this.med_eff = med_eff;
	}
	
	
}
