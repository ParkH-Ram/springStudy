/**
*PhamacyBean.java
*/


package org.example.bean;

public class PhamacyBean {
	
	private String phmy_id; 
	private String phmy_name; 
	private String phmy_addr; 
	private String phmy_repre_phmist;
	private String phmy_tel;
	private String phmy_Img;
	//private String phmy_repre_phmist;
	
	public String getPhmy_Img() {
		return phmy_Img;
	}
	public void setPhmy_Img(String phmy_Img) {
		this.phmy_Img = phmy_Img;
	}
	public String getPhmy_id() {
		return phmy_id;
	}
	public void setPhmy_id(String phmy_id) {
		this.phmy_id = phmy_id;
	}
	public String getPhmy_name() {
		return phmy_name;
	}
	public void setPhmy_name(String phmy_name) {
		this.phmy_name = phmy_name;
	}
	public String getPhmy_addr() {
		return phmy_addr;
	}
	public void setPhmy_addr(String phmy_addr) {
		this.phmy_addr = phmy_addr;
	}
	public String getPhmy_repre_phmist() {
		return phmy_repre_phmist;
	}
	public void setPhmy_repre_phmist(String phmy_repre_phmist) {
		this.phmy_repre_phmist = phmy_repre_phmist;
	}
	public String getPhmy_tel() {
		return phmy_tel;
	}
	public void setPhmy_tel(String phmy_tel) {
		this.phmy_tel = phmy_tel;
	}
	
	
}
