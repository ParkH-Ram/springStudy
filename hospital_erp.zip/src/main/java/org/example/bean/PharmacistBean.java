/**
*PharmacistBean.java
*/


package org.example.bean;

public class PharmacistBean {
	
	private String phmist_id;
	private String phmist_pwd;
	private String phmist_name;
	private String phmist_age;
	private String phmist_sex;
	private String phmist_birthday;
	private String phmist_addr;
	private String phmist_tel;
	private String phmist_phon;
	
	
	public String getPhmist_id() {
		return phmist_id;
	}
	public void setPhmist_id(String phmist_id) {
		this.phmist_id = phmist_id;
	}
	public String getPhmist_pwd() {
		return phmist_pwd;
	}
	public void setPhmist_pwd(String phmist_pwd) {
		this.phmist_pwd = phmist_pwd;
	}
	public String getPhmist_name() {
		return phmist_name;
	}
	public void setPhmist_name(String phmist_name) {
		this.phmist_name = phmist_name;
	}
	public String getPhmist_age() {
		return phmist_age;
	}
	public void setPhmist_age(String phmist_age) {
		this.phmist_age = phmist_age;
	}
	public String getPhmist_sex() {
		return phmist_sex;
	}
	public void setPhmist_sex(String phmist_sex) {
		this.phmist_sex = phmist_sex;
	}
	public String getPhmist_birthday() {
		return phmist_birthday;
	}
	public void setPhmist_birthday(String phmist_birthday) {
		this.phmist_birthday = phmist_birthday;
	}
	public String getPhmist_addr() {
		return phmist_addr;
	}
	public void setPhmist_addr(String phmist_addr) {
		this.phmist_addr = phmist_addr;
	}
	public String getPhmist_tel() {
		return phmist_tel;
	}
	public void setPhmist_tel(String phmist_tel) {
		this.phmist_tel = phmist_tel;
	}
	public String getPhmist_phon() {
		return phmist_phon;
	}
	public void setPhmist_phon(String phmist_phon) {
		this.phmist_phon = phmist_phon;
	}
	
	
	
}
