/**
*ReservBean.java
*/


package org.example.bean;

public class ReservBean {
	
	private String hosp_name;
	private String hosp_tel;
	private String hosp_addr;
	private String dcr_name;
	private String dcr_id;
	private String hosp_cd;
	
	
	public String getHosp_name() {
		return hosp_name;
	}
	public void setHosp_name(String hosp_name) {
		this.hosp_name = hosp_name;
	}
	public String getHosp_tel() {
		return hosp_tel;
	}
	public void setHosp_tel(String hosp_tel) {
		this.hosp_tel = hosp_tel;
	}
	public String getHosp_addr() {
		return hosp_addr;
	}
	public void setHosp_addr(String hosp_addr) {
		this.hosp_addr = hosp_addr;
	}
	public String getDcr_name() {
		return dcr_name;
	}
	public void setDcr_name(String dcr_name) {
		this.dcr_name = dcr_name;
	}
	public String getDcr_id() {
		return dcr_id;
	}
	public void setDcr_id(String dcr_id) {
		this.dcr_id = dcr_id;
	}
	public String getHosp_cd() {
		return hosp_cd;
	}
	public void setHosp_cd(String hosp_cd) {
		this.hosp_cd = hosp_cd;
	}
	
	

}
