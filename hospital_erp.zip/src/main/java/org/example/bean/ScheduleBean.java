/**
 * 
 * @file name:  schedulebean.java
 * @ schedulebean_cheak 
 *
 */
package org.example.bean;

public class ScheduleBean {

	private String schle_chaek;

	public ScheduleBean(){
		schle_chaek = null;
	}
	public String getSchle_chaek() {
		return schle_chaek;
	}

	public void setSchle_chaek(String schle_chaek) {
		this.schle_chaek =schle_chaek;
	}
	
}
