package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.example.bean.DiagnosisBean;
import org.example.epms.DiagnosisNew;
import org.example.DBconnection.DBConnectionMgr;

public class DiagnosisMgr {
	private DBConnectionMgr pool = null;
	private String srch = null;
	private String cols = null;
	private String todays = "";
	private static String seq = "dign0001";
	private static String id = null;
	private static JTable jtr = null;
	private Calendar toDay = Calendar.getInstance();
	private String [] title = {"이름","나이","성별","주소","전화번호"};
	Vector list = new Vector();
	Vector list2 = new Vector();
	
	public DiagnosisMgr(){
		try{
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e){
			System.out.println("Error: 커넥션 가져오기 실패!!");
		}
	}
	
	public void setSearch(String srch){
		this.srch = srch;
	}
	
	public Vector getSerch(){
		Vector v_login = new Vector();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String strQuery = null;
		
		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			strQuery = "select * from MEMBER where mem_name like '%"+srch+"%'";
			rs = stmt.executeQuery(strQuery);
			
			while(rs.next()){
				DiagnosisBean diagnosisBean = new DiagnosisBean();
				diagnosisBean.setMem_id(rs.getString(1));
				diagnosisBean.setMem_pwd(rs.getString(2));
				diagnosisBean.setMem_name(rs.getString(3));
				diagnosisBean.setMem_age(rs.getString(4));
				diagnosisBean.setMem_sex(rs.getString(5));
				diagnosisBean.setMem_birthday(rs.getString(5));
				diagnosisBean.setMem_addr(rs.getString(5));
				diagnosisBean.setMem_tel(rs.getString(5));
				diagnosisBean.setMem_job(rs.getString(5));
				diagnosisBean.setMem_phon(rs.getString(5));
				v_login.addElement(diagnosisBean);
			}
		}catch(Exception e){
			System.out.println("getServh() Exception"+ e);
		}finally{
			pool.freeConnection(con,stmt,rs);
		}
		return v_login;
	}
	
	public void getTableList(JTable jtr_mem,String title[]){
		jtr = jtr_mem;
		list = getSerch();
		
		if(list.size() == 0){
			JOptionPane.showMessageDialog(null, "검색한 내용이 없습니다");
			DefaultTableModel dt = new DefaultTableModel(title, list.size());
			jtr_mem.setModel(dt);
			/*jtr_mem.getColumn("이름").setPreferredWidth(80);
			jtr_mem.getColumn("나이").setPreferredWidth(60);
			jtr_mem.getColumn("성별").setPreferredWidth(60);
			jtr_mem.getColumn("주소").setPreferredWidth(220);
			jtr_mem.getColumn("전화번호").setPreferredWidth(120);*/
		}else{
			DefaultTableModel dt = new DefaultTableModel(title, list.size());
			jtr_mem.setModel(dt);
			/*jtr_mem.getColumn("이름").setPreferredWidth(80);
			jtr_mem.getColumn("나이").setPreferredWidth(60);
			jtr_mem.getColumn("성별").setPreferredWidth(60);
			jtr_mem.getColumn("주소").setPreferredWidth(220);
			jtr_mem.getColumn("전화번호").setPreferredWidth(120);*/
			
			for(int i = 0; i < list.size(); i++){
				int count = 0;
				DiagnosisBean diagnosisBean = (DiagnosisBean) list.elementAt(i);
				dt.setValueAt(diagnosisBean.getMem_name(), i, count++);
				dt.setValueAt(diagnosisBean.getMem_age(), i, count++);
				dt.setValueAt(diagnosisBean.getMem_sex(), i, count++);
				dt.setValueAt(diagnosisBean.getMem_addr(), i, count++);
				dt.setValueAt(diagnosisBean.getMem_tel(), i, count++);
			}
		}
	}
	
	public void reset(){
		if(jtr == null){
			DefaultTableModel dt = new DefaultTableModel(title, list.size());
			jtr.setModel(dt);
			/*jtr.getColumn("이름").setPreferredWidth(80);
			jtr.getColumn("나이").setPreferredWidth(60);
			jtr.getColumn("성별").setPreferredWidth(60);
			jtr.getColumn("주소").setPreferredWidth(220);
			jtr.getColumn("전화번호").setPreferredWidth(120);*/
		}
	}
	
	public Vector getDign(){
		Vector dignV = new Vector();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String strQuery = null;
		
		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			strQuery = "select * from DIAGNOSIS where mem_name like '%"+srch+"%'";
			rs = stmt.executeQuery(strQuery);
			
			while(rs.next()){
				DiagnosisBean diagnosisBean = new DiagnosisBean();
				diagnosisBean.setDign_cd(rs.getString(1));
				diagnosisBean.setDign_dise(rs.getString(2));
				diagnosisBean.setDign_insertDay(rs.getString(3));
				diagnosisBean.setDign_year(rs.getString(4));
				diagnosisBean.setDign_month(rs.getString(5));
				diagnosisBean.setDign_day(rs.getString(6));
				diagnosisBean.setDign_med(rs.getString(7));
				dignV.addElement(diagnosisBean);
			}
		}catch(Exception e){
			System.out.println("getServh() Exception"+ e);
		}finally{
			pool.freeConnection(con,stmt,rs);
		}
		return dignV;
	}
	
	public void getValue(){
		list2 = getDign();
	}
	
	public void getDetail(int num){
		DiagnosisNew diagnosisNew = new DiagnosisNew();
		DiagnosisBean diagnosisBean = (DiagnosisBean) list.elementAt(num);
		diagnosisNew.setValue(diagnosisBean.getMem_name(),diagnosisBean.getMem_sex(),
				diagnosisBean.getMem_birthday(),diagnosisBean.getMem_age(),
				diagnosisBean.getMem_tel(),diagnosisBean.getMem_addr());
		id = diagnosisBean.getMem_id();
	}
	
	public void save(String dise,String year,String month,String day,String med){
		todays = Integer.toString(toDay.get(Calendar.YEAR))+"년" +
				 Integer.toString(toDay.get(Calendar.MONTH)+1)+"월" +
				 Integer.toString(toDay.get(Calendar.DATE))+"일";
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String strQuery = null;
		
		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			strQuery = "select max(dign_cd) from DIAGNOSIS";
			rs = stmt.executeQuery(strQuery);
			
			while(rs.next()){
				seq = rs.getString(1);
			}
		}catch(Exception e){
			System.out.println("getServh() Exception"+ e);
		}finally{
			pool.freeConnection(con,stmt,rs);
		}
		
		String sub = seq.substring(0, 4);
		int temp = Integer.parseInt(seq.subSequence(5, 8).toString());
		temp++;
		
		if(temp < 10){
			sub = sub + "000" + temp;
		}else if(temp < 100 || temp > 10){
			sub = sub + "00" + temp;
		}else if(temp < 1000 || temp > 100){
			sub = sub + "0" + temp;
		}else if(temp < 10000 || temp > 1000){
			sub = sub + temp;
		}
		
		if(med.equals("")){
			med = null;
		}
		
		con = null;
		stmt = null;
		rs = null;
		strQuery = null;
		
		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			strQuery = "insert into DIAGNOSIS(dign_cd,dign_dise,dign_insertDay,dign_year,"+
					   "dign_month,dign_day,dign_med,mem_id)"+
					   "values('"+sub+"','"+dise+"','"+todays+"','"+year+"','"+month+
					   "','"+day+"','"+med+"','"+id+"')";
			rs = stmt.executeQuery(strQuery);
			
			while(rs.next()){
				seq = rs.getString(1);
			}
		}catch(Exception e){
			System.out.println("getServh() Exception"+ e);
		}finally{
			pool.freeConnection(con,stmt,rs);
		}
		
	}		
}