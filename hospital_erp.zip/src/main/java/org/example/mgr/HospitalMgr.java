/**
 *
 *
 *
 *
 *
 */
package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.example.epms.HospDetail;
import org.example.epms.PhmyDetail;
import org.example.DBconnection.DBConnectionMgr;

import org.example.bean.HospitalBean;
import org.example.bean.PhamacyBean;
import java.util.Iterator;

public class HospitalMgr {

    private DBConnectionMgr pool = null;
    private String srch = null;
    private String cols = null;
    private static JTable jtr = null;
    static Vector list = new Vector();
    private String[] title = {"병원명", "전화번호", "주소", "홈페이지"};

    public HospitalMgr() {
        try {
            pool = DBConnectionMgr.getInstance();
        } catch (Exception e) {
            System.out.println("Error: 커넥션 가져오기 실패!!");
        }
    }

    public void setSerch(String cols, String srch) {
        if (cols.equals("병원명")) {
            this.cols = "hosp_name";
        } else {
            this.cols = "hosp_addr";
        }

        this.srch = srch;

    }

    public void set(JTable jtr) {
        this.jtr = jtr;
    }

    public Vector getSerch() {

        Vector v_login = new Vector();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String strQuery = null;

        try {
            con = pool.getConnection();
            stmt = con.createStatement();
            strQuery = "select * from HOSPITAL where " + cols + " like '%" + srch + "%'";
            rs = stmt.executeQuery(strQuery);

            while (rs.next()) {
                HospitalBean hospitalBean = new HospitalBean();
                hospitalBean.setHosp_cd(rs.getString(1));
                hospitalBean.setHosp_name(rs.getString(2));
                hospitalBean.setHosp_tel(rs.getString(3));
                hospitalBean.setHosp_addr(rs.getString(4));
                hospitalBean.setHosp_homepage(rs.getString(5));
                hospitalBean.setHosp_fax(rs.getString(6));
                hospitalBean.setHosp_img(rs.getString(7));
                v_login.addElement(hospitalBean);
            }
        } catch (Exception e) {
            System.out.println("getSerch() Exception" + e);
        } finally {
            pool.freeConnection(con, stmt, rs);
        }
        return v_login;
    }

    public void getMoveMini(JTable jtr_hosp, String title[]) {
        list = getSerch();
        ReservMgr reservMgr = new ReservMgr();
        reservMgr.getTableListMini(jtr_hosp, title, list);
    }

    public void setHospCd(int num) {
        HospitalBean hospitalBean = (HospitalBean) list.elementAt(num);
        ReservMgr reservMgr = new ReservMgr();
        reservMgr.Set_HospCd(hospitalBean.getHosp_cd());
    }

    public void getTableListMini(JTable jtr_hosp, String title[]) {
        list = getSerch();

        if (list.size() == 0) {
            JOptionPane.showMessageDialog(null, "검색한 내용이 없습니다");
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr_hosp.setModel(dt);
            //jtr_hosp.getColumn("병원명").setPreferredWidth(80);
            //jtr_hosp.getColumn("전화번호").setPreferredWidth(110);
            //jtr_hosp.getColumn("주소").setPreferredWidth(200);
            //jtr_hosp.getColumn("홈페이지").setPreferredWidth(150);
        } else {
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr_hosp.setModel(dt);
            //jtr_hosp.getColumn("병원명").setPreferredWidth(80);
            //jtr_hosp.getColumn("전화번호").setPreferredWidth(110);
            //jtr_hosp.getColumn("주소").setPreferredWidth(200);
            //jtr_hosp.getColumn("홈페이지").setPreferredWidth(150);

            for (int i = 0; i < list.size(); i++) {
                int count = 0;
                HospitalBean hospitalBean = (HospitalBean) list.elementAt(i);
                dt.setValueAt(hospitalBean.getHosp_name(), i, count++);
                dt.setValueAt(hospitalBean.getHosp_tel(), i, count++);
                dt.setValueAt(hospitalBean.getHosp_addr(), i, count++);
                dt.setValueAt(hospitalBean.getHosp_homepage(), i, count++);
            }
        }
    }

    public void reset() {
        if (jtr == null) {
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr.setModel(dt);
            //jtr.getColumn("병원명").setPreferredWidth(80);
            //jtr.getColumn("전화번호").setPreferredWidth(110);
            //jtr.getColumn("주소").setPreferredWidth(280);
            //jtr.getColumn("홈페이지").setPreferredWidth(150);
        }
    }

    /*public void getDetail(int num){
    HospDetail hospDetail = new HospDetail();
    HospitalBean hospitalBean = (HospitalBean)list.elementAt(num);
    hospDetail.setValue(hospitalBean.getHosp_name(),hospitalBean.getHosp_addr(),
    hospitalBean.getHosp_tel(),hospitalBean.getHosp_homepage(),
    hospitalBean.getHosp_fax(),hospitalBean.getHosp_img());
    }*/
    /* public HospDetail getDetail(int num){
    HospDetail hospDetail = new HospDetail();
    HospitalBean hospitalBean = (HospitalBean)list.elementAt(num);
    hospDetail.setValue(hospitalBean.getHosp_name(),hospitalBean.getHosp_addr(),
    hospitalBean.getHosp_tel(),hospitalBean.getHosp_homepage(),
    hospitalBean.getHosp_fax(),hospitalBean.getHosp_img());
    return hospDetail;
    }*/
    
    public String Get_Hosp_serch_Code(String hosp_name){
        
        String Hosp_code = null; 
        if(!list.isEmpty()){
            Iterator itr = list.iterator();
            
            while(itr.hasNext()){
                
                HospitalBean temp = (HospitalBean)itr.next();
                
                if(temp.getHosp_name().equals(hosp_name)){
                    
                    Hosp_code = temp.getHosp_cd();
                    break;
                }
            }
        }else{
            
            JOptionPane.showMessageDialog(null, "해당 정보 내용이 없삼스");
            
        }
        
        return Hosp_code;
    }
    
    public HospitalBean getDetail(int num) {
        
        HospitalBean hospitalBean = (HospitalBean) list.elementAt(num);
        return hospitalBean;
        
    }
}
