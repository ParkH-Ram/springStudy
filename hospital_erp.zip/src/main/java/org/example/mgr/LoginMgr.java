package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import org.example.bean.LoginBean;
import org.example.bean.MedBean;
import org.example.DBconnection.DBConnectionMgr;
import javax.swing.JOptionPane;

public class LoginMgr {

    private DBConnectionMgr pool;
    private String temp2;
    private String temp3;
    private boolean login_flag = false; //로그인 상태 체크
    private static LoginMgr Instance = null;
    Vector list = new Vector();

    public static LoginMgr getInstance() {
        if (Instance == null) {
            Instance = new LoginMgr();
            Instance.Release();
        }
        return Instance;
    }

    public boolean isLogin_flag() {
        return login_flag;
    }

    public void setLogin_flag(boolean login_flag) {
        this.login_flag = login_flag;
    }

    public void Release() {
        this.login_flag = false;
        this.temp2 = null;
        this.temp3 = null;
        list.removeAllElements();
    }

    public LoginMgr() {
        try {
            pool = DBConnectionMgr.getInstance();
        } catch (Exception e) {
            System.out.println("Error: 커넥션 가져오기 실패!!");
        }
    }

    public void getJob(String temp) {
        if (temp.equals("고객")) {
            temp2 = "member";
            temp3 = "mem_id,mem_pwd";
        } else if (temp.equals("의사")) {
            temp2 = "doctor";
            temp3 = "dcr_id,dcr_pwd";
        } else {
            temp2 = "pharmacist";
            temp3 = "phmist_id,phmist_pwd";
        }

        getIdList();
    }

    public Vector getIdList() {
        Vector v_login = new Vector();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String strQuery = null;

        try {
            con = pool.getConnection();
            stmt = con.createStatement();
            strQuery = "select " + temp3 + " from " + temp2;
            rs = stmt.executeQuery(strQuery);

            while (rs.next()) {
                LoginBean loginTemp = new LoginBean();
                loginTemp.setMem_id(rs.getString(1));
                loginTemp.setMem_pwd(rs.getString(2));
                v_login.addElement(loginTemp);
            }
        } catch (Exception e) {
            System.out.println("getSerch() Exception" + e);
        } finally {
            pool.freeConnection(con, stmt, rs);
        }
        return v_login;
    }

    
    public void getSearchIdPwd(String id, String pwd) {
        list = getIdList();
        boolean flag = false;
        boolean id_flag = false;
        for (int i = 0; i < list.size(); i++) {
            LoginBean loginBean = (LoginBean) list.elementAt(i);


            if (id.equals(loginBean.getMem_id())) {

                if (pwd.equals(loginBean.getMem_pwd())) {
                    //setLogin_flag(true);
                    flag = true;
                    JOptionPane.showMessageDialog(null, "정상 로그인 되었습니다");

                } else {
                    JOptionPane.showMessageDialog(null, "passWord 일치가 안됩니다");

                }
            } else {
                id_flag = true;
            }
        }
        
        if(flag){
            setLogin_flag(true);
            
        } else {
            
              setLogin_flag(false);
              JOptionPane.showMessageDialog(null, "로그인 실패 되었습니다");
                               
              }
    }
}
