package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.example.bean.DiagnosisBean;
import org.example.bean.HospitalBean;
import org.example.bean.MedBean;
import org.example.DBconnection.DBConnectionMgr;

public class MedMgr {
	private DBConnectionMgr pool;
	private String srch;
	private String cols;
	private int num;
	private static Vector medV = new Vector();
	private static JTable jtr_phmy;
	private static String [] title = {"","",""};
	Vector list = new Vector();
	Vector listValue = new Vector();
	
	public MedMgr(){
		try{
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e){
			System.out.println("Error: 커넥션 가져오기 실패!!");
		}
	}
	
	public void setSearch(String srch){
		this.srch = srch;
	}
	
	public Vector getSerch(){
        @SuppressWarnings("UseOfObsoleteCollectionType")
		Vector v_login = new Vector();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String strQuery = null;
		
		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			
                        strQuery = "select med_cd,med_name,med_ucost,med_eff from " + 
                                " MEDICINEINFO where med_name like '%" + srch + "%' ";
			rs = stmt.executeQuery(strQuery);
			
			while(rs.next()){
				MedBean medBean = new MedBean();
				medBean.setMed_cd(rs.getString(1));
				medBean.setMed_name(rs.getString(2));
				medBean.setMed_ucost(rs.getString(3));
				medBean.setMed_eff(rs.getString(4));
				v_login.addElement(medBean);
			}
		}catch(Exception e){
			System.out.println("getServh() Exception"+ e);
		}finally{
			pool.freeConnection(con,stmt,rs);
		}
		return v_login;
	}
	
	public void getTableList(JTable jtr_med,String title[]){
		list = getSerch();
		
		if(list.size() == 0){
			JOptionPane.showMessageDialog(null, "검색한 내용이 없습니다");
			DefaultTableModel dt = new DefaultTableModel(title, list.size());
			jtr_med.setModel(dt);
			//jtr_med.getColumn("약효명").setPreferredWidth(100);
			//jtr_med.getColumn("약효").setPreferredWidth(230);
			//jtr_med.getColumn("단가").setPreferredWidth(70);
		}else{
			DefaultTableModel dt = new DefaultTableModel(title, list.size());
			jtr_med.setModel(dt);
			//jtr_med.getColumn("약효명").setPreferredWidth(100);
			//jtr_med.getColumn("약효").setPreferredWidth(230);
			//jtr_med.getColumn("단가").setPreferredWidth(70);
			
			for(int i=0; i < list.size(); i++){
				int count = 0;
				MedBean medBean = (MedBean) list.elementAt(i);
				dt.setValueAt(medBean.getMed_name(), i, count++);
				dt.setValueAt(medBean.getMed_eff(), i, count++);
				dt.setValueAt(medBean.getMed_ucost(), i, count++);
			}
		}
	}	
	
	public void getNum(int num){
		this.num = num;
	}
	public void setTable(JTable jtr_phmy,String title[]){
		this.jtr_phmy = jtr_phmy;
		this.title = title;
	}
	
	public void getValue(){
		MedBean medValueBean = new MedBean();
		MedBean medBean = (MedBean) list.elementAt(0);
		medValueBean.setMed_cd(medBean.getMed_cd());
		medValueBean.setMed_name(medBean.getMed_name());
		medValueBean.setMed_eff(medBean.getMed_eff());
		medValueBean.setMed_ucost(medBean.getMed_ucost());
		medV.add(medValueBean);
		
		DefaultTableModel dt = new DefaultTableModel(title, medV.size());
		jtr_phmy.setModel(dt);
		//jtr_phmy.getColumn("약효명").setPreferredWidth(140);
		//jtr_phmy.getColumn("약효").setPreferredWidth(400);
		//jtr_phmy.getColumn("단가").setPreferredWidth(100);
		
		for(int i = 0; i < medV.size(); i++){
			int count = 0;
			MedBean medBean2 = (MedBean) medV.elementAt(i);
			dt.setValueAt(medBean2.getMed_name(), i, count++);
			dt.setValueAt(medBean2.getMed_eff(), i, count++);
			dt.setValueAt(medBean2.getMed_ucost(), i, count++);
		}
	}
	
	public void getDelte(int row){
		medV.removeElement(row);
		
		DefaultTableModel dt = new DefaultTableModel(title, medV.size());
		jtr_phmy.setModel(dt);
		//jtr_phmy.getColumn("약효명").setPreferredWidth(140);
		//jtr_phmy.getColumn("약효").setPreferredWidth(400);
		//jtr_phmy.getColumn("단가").setPreferredWidth(100);
		
		for(int i = 0; i < medV.size(); i++){
			int count = 0;
			MedBean medBean2 = (MedBean) medV.elementAt(i);
			dt.setValueAt(medBean2.getMed_name(), i, count++);
			dt.setValueAt(medBean2.getMed_eff(), i, count++);
			dt.setValueAt(medBean2.getMed_ucost(), i, count++);
		}
	}
	
	public void reset(){
		medV.removeAllElements();
		
		if(jtr_phmy == null){
			DefaultTableModel dt = new DefaultTableModel(title, medV.size());
			jtr_phmy.setModel(dt);
			//jtr_phmy.getColumn("약효명").setPreferredWidth(140);
			//jtr_phmy.getColumn("약효").setPreferredWidth(400);
			//jtr_phmy.getColumn("단가").setPreferredWidth(100);
		}
	}
	
	public String medValue(){
		String med = "";
		for(int i=0; i < medV.size(); i++){
			//int count = 0;
			MedBean medBean2 = (MedBean) medV.elementAt(i);
			med = med + medBean2.getMed_cd();
		}
		
		return med;
	}
}