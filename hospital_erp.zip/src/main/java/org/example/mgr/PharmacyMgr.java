/**
 *
 *
 *
 *
 *
 */
package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.example.epms.PhmyDetail;
import org.example.DBconnection.DBConnectionMgr;
import org.example.bean.PhamacyBean;

public class PharmacyMgr {

    private DBConnectionMgr pool;
    private String srch;
    private String cols;
    private static JTable jtr;
    Vector list = new Vector();
    private String[] title = {"약국명", "전화번호", "대표 약사", "주소"};

    public PharmacyMgr() {
        try {
            pool = DBConnectionMgr.getInstance();
        } catch (Exception e) {
            System.out.println("Error : 커넥션 가져오기 실패");
        }
    }

    public void setSearch(String cols, String srch) {
        if (cols.equals("주소")) {
            this.cols = "phmy_addr";
        } else {
            this.cols = "phmy_name";
        }

        this.srch = srch;
    }

    public void reset() {
        if (jtr == null) {
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr.setModel(dt);
            //jtr.getColumn("약국명").setPreferredWidth(80);
            //jtr.getColumn("전화번호").setPreferredWidth(90);
            //jtr.getColumn("대표 약사").setPreferredWidth(90);
            //jtr.getColumn("주소").setPreferredWidth(280);
        }
    }

    public Vector getSerch() {

        list.removeAllElements();
        Vector v_login = new Vector();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String strQuery = null;

        try {
            con = pool.getConnection();
            stmt = con.createStatement();
            //strQuery = "select * from PHARMACY where "+cols+" like '%"+srch+"%'";
            // strQuery =  "select * from pharmacy where phmy_name like '우성약국'"; 

            strQuery = "select * from pharmacy where " + this.cols + " like '%" + this.srch + "%'";
            rs = stmt.executeQuery(strQuery);

            while (rs.next()) {
                PhamacyBean phamacyBean = new PhamacyBean();
                phamacyBean.setPhmy_id(rs.getString(1));
                phamacyBean.setPhmy_name(rs.getString(2));
                phamacyBean.setPhmy_addr(rs.getString(3));
                phamacyBean.setPhmy_Img(rs.getString(4));
                phamacyBean.setPhmy_repre_phmist(rs.getString(5));
                phamacyBean.setPhmy_tel(rs.getString(6));
                v_login.addElement(phamacyBean);
            }
        } catch (Exception e) {
            System.out.println("getSerch() Exception" + e);
        } finally {
            pool.freeConnection(con, stmt, rs);
        }
        return v_login;
    }

    public void getTableList(JTable jtr_phmy, String title[]) {
        jtr = jtr_phmy;
        list = getSerch();

        if (list.size() == 0) {

            JOptionPane.showMessageDialog(null, "검색한 내용이 없습니다");
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr_phmy.setModel(dt);
            //jtr_phmy.getColumn("약국명").setPreferredWidth(80);
            //jtr_phmy.getColumn("전화번호").setPreferredWidth(90);
            //jtr_phmy.getColumn("대표 약사").setPreferredWidth(90);
            //jtr_phmy.getColumn("주소").setPreferredWidth(280);
        } else {
            DefaultTableModel dt = new DefaultTableModel(title, list.size());
            jtr_phmy.setModel(dt);
            //jtr_phmy.getColumn("약국명").setPreferredWidth(80);
            //jtr_phmy.getColumn("전화번호").setPreferredWidth(90);
            //jtr_phmy.getColumn("대표 약사").setPreferredWidth(90);
            //jtr_phmy.getColumn("주소").setPreferredWidth(280);

            for (int i = 0; i < list.size(); i++) {

                int count = 0;
                PhamacyBean phamacyBean = (PhamacyBean) list.elementAt(i);
                dt.setValueAt(phamacyBean.getPhmy_name(), i, count++);
                dt.setValueAt(phamacyBean.getPhmy_tel(), i, count++);
                dt.setValueAt(phamacyBean.getPhmy_repre_phmist(), i, count++);
                dt.setValueAt(phamacyBean.getPhmy_addr(), i, count++);

            }
        }
    }

    /*public void getDetail(int num){
    PhmyDetail phmyDetail = new PhmyDetail();
    PhamacyBean phamacyBean = (PhamacyBean)list.elementAt(num);
    phmyDetail.setValue(phamacyBean.getPhmy_name(),phamacyBean.getPhmy_addr(),
    phamacyBean.getPhmy_tel(),phamacyBean.getPhmy_repre_phmist(),
    phamacyBean.getPhmy_Img());
    }*/
    
    
    
    public PhmyDetail getDetail(int num) {
        
        PhmyDetail phmyDetail = new PhmyDetail();
        PhamacyBean phamacyBean = (PhamacyBean) list.elementAt(num);
        phmyDetail.setValue(phamacyBean.getPhmy_name(), phamacyBean.getPhmy_addr(),
                phamacyBean.getPhmy_tel(), phamacyBean.getPhmy_repre_phmist(),
                phamacyBean.getPhmy_Img());

        return phmyDetail;
    }
}
