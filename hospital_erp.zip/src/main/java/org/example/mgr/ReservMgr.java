/**
 *
 *
 *
 *
 *
 */
package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.example.bean.HospitalBean;
import org.example.bean.ReservBean;
import org.example.epms.*;
import org.example.DBconnection.DBConnectionMgr;
import java.util.Iterator;

public class ReservMgr {

    static Vector list = new Vector();
    private DBConnectionMgr pool;
    private static String hospCd;
    private String doctor_id = null;
    private String Reserver_id = null;

    
    
    public void setReserver_id(String Reserver_id) {
        this.Reserver_id = Reserver_id;
    }
   

    
    private void serch_doctor_cd(String name){
        
        if(!list.isEmpty()){
            for(int i = 0; i < list.size(); i++){
                //if
                ReservBean reservBean = (ReservBean) list.elementAt(i); 
                String doctor_name = reservBean.getDcr_name();
                
                
                if(name.equals(name)){
                    
                    
                    doctor_id = reservBean.getDcr_id();
                    
                }
            }
        }
    }
    
     
    public ReservMgr() {
        try {
            pool = DBConnectionMgr.getInstance();
        } catch (Exception e) {
            System.out.println("Error : 커넥션 가져오기 실패");
        }
    }

    public void Set_HospCd(String hospCd) {
        this.hospCd = hospCd;
    }

    public Vector getSerchMini() {

        Vector v_login = new Vector();
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String strQuery = null;

        try {
            con = pool.getConnection();
            stmt = con.createStatement();
            strQuery = "select h.hosp_name,h.hosp_tel,h.hosp_addr,d.dcr_name,d.dcr_id "
            + "from HOSPITAL h,DOCTOR d "
            + "where h.hosp_cd = d.hosp_cd and h.hosp_cd ='"+ hospCd + "'";
        

            
            rs = stmt.executeQuery(strQuery);

            while (rs.next()) {
                ReservBean reservBean = new ReservBean();
                reservBean.setHosp_cd(hospCd);
                reservBean.setHosp_name(rs.getString(1));
                reservBean.setHosp_tel(rs.getString(2));
                reservBean.setHosp_addr(rs.getString(3));
                reservBean.setDcr_name(rs.getString(4));
                reservBean.setDcr_id(rs.getString(5));
                v_login.addElement(reservBean);
            }
        } catch (Exception e) {
            System.out.println("getServh() Exception" + e);
        } finally {
            pool.freeConnection(con, stmt, rs);
        }
        return v_login;
    }

   

    public Vector<ReservBean> getReservDoctor() {
        
        list = getSerchMini();
        Vector<ReservBean> info = null;
        
        if (list.size() == 0) {
            
        } else {
            
            int count = list.size();
            info = new Vector<ReservBean>();
            
            for (int i = 0; i < count; i++) {
                
                ReservBean reservBean = (ReservBean) list.elementAt(i);
                info.add(reservBean);
                
            }
        }

        return info;
    }


    // 데이터 입력 해서 쿼리 인서트
    public void setInsert(String time, String year, String month, String day, String dotcor) {
        
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String strQuery = null;

        serch_doctor_cd(dotcor); 
        
        try {
            con = pool.getConnection();
            stmt = con.createStatement();
          
            
          
            
                
            strQuery = "insert into reservation"+
                    "(reserv_time,dcr_id,hosp_id,mem_id,reserv_date)"+
                       "values('"+time +"','"+doctor_id+"','"+hospCd+"','"+Reserver_id+"','"
                       +year+month+day+"')";
           
           
            stmt.executeQuery(strQuery);
        } catch (Exception e) {
            System.out.println("getSerch() Exception" + e);
        } finally {
            pool.freeConnection(con, stmt, rs);
        }
    }

    public void getTableListMini(JTable jtr_hosp, String title[], Vector list2) {
        if (list2.size() == 0) {
            JOptionPane.showMessageDialog(null, "검색한 내용이 없습니다");
            DefaultTableModel dt = new DefaultTableModel(title, list2.size());
            jtr_hosp.setModel(dt);
            //jtr_hosp.getColumn("병원명").setPreferredWidth(75);
            //jtr_hosp.getColumn("전화번호").setPreferredWidth(90);
            //jtr_hosp.getColumn("주소").setPreferredWidth(160);
        } else {
            DefaultTableModel dt = new DefaultTableModel(title, list2.size());
            jtr_hosp.setModel(dt);
            //jtr_hosp.getColumn("병원명").setPreferredWidth(75);
            //jtr_hosp.getColumn("전화번호").setPreferredWidth(90);
            //jtr_hosp.getColumn("주소").setPreferredWidth(160);

            for (int i = 0; i < list2.size(); i++) {
                int count = 0;
                HospitalBean hospitalBean = (HospitalBean) list2.elementAt(i);
                dt.setValueAt(hospitalBean.getHosp_name(), i, count++);
                dt.setValueAt(hospitalBean.getHosp_tel(), i, count++);
                dt.setValueAt(hospitalBean.getHosp_addr(), i, count++);
            }
        }
    }
}
