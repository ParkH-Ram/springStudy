/**
*ScheduleMgr.java
*/

package org.example.mgr;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import org.example.DBconnection.DBConnectionMgr;
import org.example.bean.ScheduleBean;

public class ScheduleMgr {
	private DBConnectionMgr pool;
	//private static String dcr_id = "ult001";
	private static String schle_chreck[] = new String[31] ;
	//private Vector<Object> list = null;

	public ScheduleMgr(){
		//list = new Vector<Object>();
		
		try{
			pool = DBConnectionMgr.getInstance();
		}catch (Exception e) {
			// TODO: handle exception

			System.out.println("connection error");
		}
	}

	public void getSearch(){
		
		int num = 0;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String str_Query = null;

		try{
			con = pool.getConnection();
			stmt = con.createStatement();
			str_Query = ""; // insert Query 
			rs = stmt.executeQuery(str_Query);

			while(rs.next()){
				
				ScheduleBean scheduleBean = new ScheduleBean();
				scheduleBean.setSchle_chaek(rs.getNString(1));
				for(int i = 0; i < rs.getString(1).length()-2;){
					schle_chreck[num++] = new String(rs.getString(1).substring(i,i+2));
					i = i+2;
				}
				//v_Login.add(scheduleBean);
			}

		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("getSerch"+e);
		}
		finally{
			pool.freeConnection(con,stmt,rs);
		}

		
	}


}
